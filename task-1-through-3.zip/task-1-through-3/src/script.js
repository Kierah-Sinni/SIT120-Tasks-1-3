function test() {
  
  alert("test")
  alert("test")
  
}
const StudentScores = ["1", "2", "3"]